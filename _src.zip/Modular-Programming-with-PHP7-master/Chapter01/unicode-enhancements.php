<?php

echo "the € currency";
echo "the ¥ currency";
echo "the £ currency";
echo "the $ currency";

echo "the \u{1F632} face";
echo "the \u{1F609} face";
echo "the \u{1F60F} face";
