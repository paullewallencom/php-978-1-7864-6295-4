<?php

function divide(int $A, int $B) : int
{
    return $A / $B;
}

var_dump(divide(10, 2)); // int(5)

var_dump(divide(10, 3)); // int(3)
