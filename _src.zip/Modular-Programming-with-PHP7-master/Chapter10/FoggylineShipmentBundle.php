<?php

namespace Foggyline\ShipmentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FoggylineShipmentBundle extends Bundle
{
}
