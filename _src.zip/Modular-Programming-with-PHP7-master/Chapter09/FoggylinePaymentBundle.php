<?php

namespace Foggyline\PaymentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FoggylinePaymentBundle extends Bundle
{
}
